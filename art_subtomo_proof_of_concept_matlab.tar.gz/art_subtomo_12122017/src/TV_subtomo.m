addpath('Tools for Tomographic Reconstruction/Tools for Tomographic Reconstruction/');
addpath('Tools for Tomographic Reconstruction/Tools for Tomographic Reconstruction/filter/');
addpath('Tools for Tomographic Reconstruction/Tools for Tomographic Reconstruction/solver/');
addpath('Tools for Tomographic Reconstruction/Tools for Tomographic Reconstruction/utils/');

addpath('TVAL3_v1.0/');
addpath('TVAL3_v1.0/Solver/');
addpath('TVAL3_v1.0/Utilities/');
addpath('TVAL3_v1.0/Demos/');
addpath('TVAL3_v1.0/Fast_Walsh_Hadamard_Transform/');

addpath('src_art_subtomo/');
addpath('src_TV_subtomo/');

load 'simu/f_multi.mat'
load 'simu/f.mat'
load 'simu/f_range.mat'

ang_multi = [0:3:89.99;90:3:179.99];
[W_f1, p_f1, ~, ~] = build_weight_matrix(f_multi(:,:,1), ang_multi(1,:), 1, 'area');
[W_f2, p_f2, ~, ~] = build_weight_matrix(f_multi(:,:,2), ang_multi(2,:), 1, 'area');

w=size(f);

%initial
rec_f1 = zeros(w);
rec_f2 = zeros(w);
u = zeros(sum(f_range(:)),1);
sigma = 1;
lambda1 = 2^(-13);
lambda2 = 2^(-13);

M=diag(f_range(:));
M(all(M == 0, 2), :) = [];

W1_new = [W_f1; (sigma/2)^0.5*M];
W2_new = [W_f2; (sigma/2)^0.5*M];

clear opts1
opts1.mu = 2/lambda1;
opts1.beta = 2^5;
opts1.tol = 1E-3;
opts1.maxit = 3000;
opts1.TVnorm = 1;
opts1.nonneg = false;
opts1.TVL2 = true;
clear opts2
opts2.mu = 2/lambda2;
opts2.beta = 2^5;
opts2.tol = 1E-3;
opts2.maxit = 3000;
opts2.TVnorm = 1;
opts2.nonneg = false;
opts2.TVL2 = true;

for i=1:10
%iter
    p1_new = [p_f1;(sigma/2)^0.5*(rec_f2(find( f_range(:) == 1 ))-u/sigma)]; %#ok<FNDSB>
    p2_new = [p_f2;(sigma/2)^0.5*(rec_f1(find( f_range(:) == 1 ))+u/sigma)]; %#ok<FNDSB>

    %t = cputime;t = cputime - t;
    [rec_f1, out] = TVAL3(W1_new,p1_new,w(1),w(2),opts1);
    [rec_f2, out] = TVAL3(W2_new,p2_new,w(1),w(2),opts2);
    
    %[rec_f1, out] = TVAL3_ll(W1_new,p1_new,w(1),w(2),opts1,1-f_range*0.9);
    %[rec_f2, out] = TVAL3_ll(W2_new,p2_new,w(1),w(2),opts2,1-f_range*0.9);
    
    u = u + sigma*(rec_f1(find( f_range(:) == 1 )) - rec_f2(find( f_range(:) == 1 )));
    if mod(i,2)==1
        figure;imshow(rec_f1,[])
        figure;imshow(rec_f2,[])
    end
    %sigma = max(sigma *2^0.5, 2^4);
    error = rec_f1(find( f_range(:) == 1 )) - rec_f2(find( f_range(:) == 1 ));
    
    
    sum(error.^2)/size(error,1)
    
    
    if sum(error.^2)/size(error,1) < 0.01
        %break;
    end
end
%{
tom_mrcwrite(rec_f1,'name','rlt/TV_multi/f1.mrc');
tom_mrcwrite(rec_f2,'name','rlt/TV_multi/f2.mrc');
tom_mrcwrite(rec_f1.*f_range,'name','rlt/TV_multi/f1_mask.mrc');
tom_mrcwrite(rec_f2.*f_range,'name','rlt/TV_multi/f2_mask.mrc');
%}