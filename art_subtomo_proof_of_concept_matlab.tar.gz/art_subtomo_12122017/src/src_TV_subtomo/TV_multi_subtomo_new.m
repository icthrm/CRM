function [rec_f_out] = TV_multi_subtomo_new(box_size, f_range, W_f, p_f, iteration, weight_flag, number_of_particles, lambda)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%initial%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%reconstruction results
%every page stands for a particle
rec_f = zeros(box_size(1), box_size(2), number_of_particles);
[ average_TV_f ] = average_TV( box_size, f_range, W_f, p_f, weight_flag, number_of_particles, lambda );
for i=1:number_of_particles
    rec_f(:,:,i) = average_TV_f;
end
%multipliers of augmented largrangians 
%every row of u stands for a multiplier
u = zeros(sum(f_range(:)),number_of_particles);

%penalty factor of augmented largrangians
%assume sigma_1, ... , sigma_(n-1) have the save value sigma
sigma = 1;

%penalty factor of TV norm
%assume lambda_1, ... , lambda_n has the same value lambda
%lambda = 2^(-19);

%the linear mapping in constraint of particles
%M map a matrix (reconstructon) to a column vector.
M=diag(f_range(:));
M(all(M == 0, 2), :) = [];

%coefficient matrix of TV sub-problem
%independent of k (iteration term)
W_new = cell(number_of_particles,1);

for i = 1 : (number_of_particles )
    W_new{i} = [W_f{i}; (sigma/2)^0.5*M];
end

%constant term of TV sub-problem
%it depend on the k (iteration term)
p_new = cell(number_of_particles,1);

%options in TVAL3
clear opts
opts.mu = 2/lambda;
opts.beta = 2^5;
opts.tol = 1E-3;
opts.maxit = 3000;
opts.TVnorm = 1;
opts.nonneg = false;
opts.TVL2 = true;


%%%%%%%%%%%%%%%%%%%%%%%%%%%%ADMM (alternating direction method of multipliers)
for i = 1:iteration
    %update p
    tmp = mean(rec_f,3);
    %pi, i=2,...,n-1
    for j = 1:(number_of_particles)
         p_new{j} = [p_f{j};(sigma/2)^0.5*(tmp(find( f_range(:) == 1 ))-u(:,1)/sigma)]; %#ok<FNDSB>
    end

    
    %solve TV sub-problem (update rec_f)
    tic
    %t = cputime;
    %can be paralleled (parfor)
    for j = 1:number_of_particles
        
        
        size(W_new{j})
        size(p_new{j})
        
        [rec_f(:,:,j), out] = TVAL3_ll(W_new{j},p_new{j},box_size(1),box_size(2),opts,1-f_range*weight_flag);
    end
    %t = cputime - t;
    %t
    toc
    
    %update u
    for j = 1:(number_of_particles-1)
        tmp1 = rec_f(:,:,j);
        tmp2 = mean(rec_f,3);
        u(:,j) = u(:,j) + sigma*(tmp1(find( f_range(:) == 1 )) - tmp2(find( f_range(:) == 1 )));
    end
    
    %update sigma
    %sigma = max(sigma *2^0.5, 2^4); 
    

    %display the reconstructions
    if mod(i,2)==1
        figure;imshow(rec_f(:,:,1).*f_range,[])
        figure;imshow(rec_f(:,:,number_of_particles).*f_range,[])
    end

    %terminating conditions
    %{
    error = rec_f1(find( f_range(:) == 1 )) - rec_f2(find( f_range(:) == 1 ));
    sum(error.^2)/size(error,1)
    if sum(error.^2)/size(error,1) < 0.01
        %break;
    end
    %}
end
rec_f_out = rec_f(:,:,1).*f_range;
%{
tom_mrcwrite(rec_f1,'name','rlt/TV_multi/f1.mrc');
tom_mrcwrite(rec_f2,'name','rlt/TV_multi/f2.mrc');
tom_mrcwrite(rec_f1.*f_range,'name','rlt/TV_multi/f1_mask.mrc');
tom_mrcwrite(rec_f2.*f_range,'name','rlt/TV_multi/f2_mask.mrc');
%}
%t = cputime;t = cputime - t;
end