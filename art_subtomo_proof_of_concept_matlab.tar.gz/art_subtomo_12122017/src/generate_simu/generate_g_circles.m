function [ g ] = generate_g_circles( n_circle, maxf, minf, r_circle_max, r_circle_min, length)
%GENERATE_G Summary of this function goes here
%   Detailed explanation goes here


%ctime = datestr(now, 30);
%tseed = str2num(ctime((end - 5) : end)) ;
%rand('seed', tseed)

    

    g = zeros(length, length);   
    for j=1:n_circle
        omega = rand(1)*2*pi;
        r_circle = rand(1)*(r_circle_max-r_circle_min)+r_circle_min;
        r_circle = floor(r_circle);
        pixV =  rand(1)*(maxf-minf)+minf;
        x_center_circle = 3.0*length/8*cos(omega)+(1+length)/2;
        x_center_circle = floor(x_center_circle);
        y_center_circle = 3.0*length/8*sin(omega)+(1+length)/2;
        y_center_circle = floor(y_center_circle);
        range_circle_x = (x_center_circle-r_circle):(x_center_circle+r_circle);
        range_circle_y = (y_center_circle-r_circle):(y_center_circle+r_circle);
        

        
        g(range_circle_x,range_circle_y) = g(range_circle_x,range_circle_y)+mask_ring(0,r_circle,[r_circle*2+1 r_circle*2+1])*pixV;
    end


end

