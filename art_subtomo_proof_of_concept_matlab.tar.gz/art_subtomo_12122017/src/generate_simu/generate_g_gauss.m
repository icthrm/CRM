function [ g ] = generate_g_gauss( f_range, box_size, std_1, sigma)
%GENERATE_G_GAUSS Summary of this function goes here
%   Detailed explanation goes here
    g = randn(box_size);
    %norm
    g = g - mean(g(:));
    g = g/std(g(:));

    g = g*std_1;
    %low pass
    G = fft2(g);
    
    
    %imshow(abs(G),[]);
    
    
    X = 1:size(G,1);
    Y = 1:size(G,2);
    %delta = 1;
    U0 = (1 + size(G,1))/2;
    V0 = (1 + size(G,2))/2;
    %bsxplus(@plus,(X-U0).^2, (Y - V0)'.^2)
    Gauss = exp(-(bsxfun(@plus,(X-U0).^2, (Y - V0)'.^2))/(2*(sigma).^2));
    
    
    %figure;imshow(abs(Gauss),[]);
    
    
    Gauss = fftshift(Gauss);
    
    
    %figure;imshow(abs(Gauss),[]);
    
    
    G = G.*Gauss;
    
    
    %figure;imshow(G,[]);
    
    
    g = ifft2(G);
    
    
    %figure;imshow(g,[]);
    
    
    %only remain the imformation in background area
    
    g = real(g);
    
    
    g(find(g<-0.15))=-0.15;
    g(find(g>0.15))=0.15;
    g=g+0.15;
    
    g = g.*(1 - f_range);
end