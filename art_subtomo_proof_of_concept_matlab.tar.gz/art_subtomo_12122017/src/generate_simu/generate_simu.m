function [f_multi, f, f_range] = generate_simu(n, g_flag)
%n is number of samples;

%generate f
[f, maxf, minf ] = generate_f('/data/projects/constraint-reconstruction/art_subtomo_12122017/data/emd_3489_bin180_cut.map');

box_size = size(f);
f_range = mask_ring(0,ceil(box_size(1)/4),box_size);

std_f = std(f(find(f_range == 1)));
mean_f = mean(f(find(f_range == 1)));

f_multi = zeros(size(f,1), size(f,2), n);
for i=1:n
    if g_flag == 0
        g = generate_g_circles(5,maxf,minf,16,4,128);
    else
        g = generate_g_gauss( f_range, box_size, 1, 10);
        
        std_g = std(g(find(f_range == 0)));
        mean_g = mean(g(find(f_range == 0)));
        
        g = (g - mean_g) / std_g;
        g = g * std_f + mean_f;
    end
    f_multi(:,:,i) = f + g .* (1 - f_range);
end




end
