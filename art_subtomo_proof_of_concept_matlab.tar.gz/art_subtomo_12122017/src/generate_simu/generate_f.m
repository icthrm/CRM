function [f, maxf, minf ] = generate_f( input)
%GENERATE_F Summary of this function goes here
%   Detailed explanation goes here
particle=tom_mrcreadimod(input);
particle=particle.Value;
particle_mid=particle(:,:,ceil(size(particle,3)/2));
particle_mid = fliplr(particle_mid);
w=size(particle_mid);
w2=2*w;
length=w2(1);
f=zeros(w2);
f((length/4+1):(length/4*3),(length/4+1):(length/4*3))=particle_mid;
maxf=max(particle_mid(:));
minf=min(particle_mid(:));
end