function [ average_f ] = average_TV( box_size, f_range, W_f, p_f, weight_flag, number_of_particles, lambda )
%AVERAGE_TV Summary of this function goes here
%   Detailed explanation goes here
    rec_f = zeros(box_size(1), box_size(2), number_of_particles);
    %lambda = 2^(-13);
    clear opts
    opts.mu = 2/lambda;
    opts.beta = 2^5;
    opts.tol = 1E-3;
    opts.maxit = 3000;
    opts.TVnorm = 1;
    opts.nonneg = false;
    opts.TVL2 = true;
    for i=1:number_of_particles
        [rec_f(:,:,i), out] = TVAL3_ll(full(W_f{i}),p_f{i},box_size(1),box_size(2),opts,1-f_range*weight_flag);
    end
    average_f = mean(rec_f, 3) .* f_range;
end

