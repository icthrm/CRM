function [ ang_multi ] = generate_angles( number_of_particles, delta_angle, number_of_proj )
%GENERATE_ANGLES Summary of this function goes here
%   Detailed explanation goes here
    ang_tmp = 0:delta_angle:((number_of_proj-1)*delta_angle);
    start_ang = rand(number_of_particles,1)*360-180;
    ang_multi = bsxfun(@plus, ang_tmp, start_ang);
    %[-180,180]
    ang_multi = mod(ang_multi + 180, 360)-180;
end