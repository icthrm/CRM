%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%load sample data
load('rlt/simu/f_range.mat');
load('rlt/simu/W_f.mat');
load('rlt/simu/p_f.mat');
%load('rlt/simu/p_noise_f.mat');

%parameters
number_of_particles = 3;
number_of_group = 30;

%parameters average ART
box_size = size(f_range);
iter_l = 25;
mkdir rlt/rec_art_ave
%reconstruction
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    rec_f = zeros(box_size(1), box_size(2), number_of_particles);
    for j = 1:iter_l
        tic
        [ average_art_f,rec_f ] = average_ART( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), number_of_particles, 1,rec_f );
        save(['rlt/rec_art_ave/average_art_f_iter' num2str(j) '_group' num2str(i) '.mat'],'average_art_f');
        save(['rlt/rec_art_ave/average_art_original_iter' num2str(j) '_group' num2str(i) '.mat'],'rec_f');
        toc
    end
end