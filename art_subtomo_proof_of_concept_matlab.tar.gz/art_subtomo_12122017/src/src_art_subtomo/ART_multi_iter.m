function [ W_combine,p_combine  ] = ART_multi_iter( box_size, f_range, W_f, p_f, number_of_particles  )
%ART_MULTI Summary of this function goes here
%   Detailed explanation goes here

%w=size(f_multi);

%f1 = f_multi(:,:,1);
%ang_f1 = ang_multi(1,:);
%[W_f1, p_f1, ~, ~] = build_weight_matrix(f1, ang_f1, 1, 'area');
W_combine = single(full(W_f{1}));
p_combine = p_f{1};
for i=2:number_of_particles
%     f2 = f_multi(:,:,i);
%     ang_f2 = ang_multi(i,:);
%     
%     [W_f2, p_f2, ~, ~] = build_weight_matrix(f2, ang_f2, 1, 'area');
    W_f2_f_range = single(full(W_f{i}));
    W_f2_f_range(:,find(f_range(:)==0))=0;
    W_f2_f_irange = single(full(W_f{i}));
    W_f2_f_irange(:,find(f_range(:)==1))=0;

    W_combine=[W_combine, zeros(size(W_combine,1),box_size(1)*box_size(2)); W_f2_f_range, zeros(size(p_f{i},1), box_size(1)*box_size(2)*(i-2)), W_f2_f_irange];
    p_combine=[p_combine;p_f{i}];
end
%rec_combine = solver_art(W_combine,p_combine,size(W_combine,1)*iter_l);
%figure;imshow(reshape(rec_combine(1:(w(1)*w(2))),[w(1),w(2)]),[])
%output = reshape(rec_combine(1:(box_size(1)*box_size(2))), box_size);

end