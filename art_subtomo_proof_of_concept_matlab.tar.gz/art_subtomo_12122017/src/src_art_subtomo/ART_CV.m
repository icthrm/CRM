function [ out_f, rec_f] = ART_CV( box_size, f_range, W_f, p_f, number_of_particles, iter_l,rec_f)
%AVERAGE_ART Summary of this function goes here
%   Detailed explanation goes here

    %initial
    %rec_f = zeros(box_size(1)*box_size(2), number_of_particles);
    f_vec = rec_f(:,number_of_particles).*f_range(:);
    for j = 1:iter_l
        for i = 1:number_of_particles
            rec_f(:,i) = rec_f(:,i).*(1-f_range(:)) + f_vec;
            rec_f(:,i) = solver_art_ll(full(W_f{i}), p_f{i}, size(full(W_f{i}),1),rec_f(:,i));
            f_vec = rec_f(:,i).*f_range(:);
        end
        %mean((average_f_vec - average_f_vec_old).^2, 1)
        %figure;imshow(reshape(rec_f(:,1), box_size), []);
        %figure;imshow(reshape(rec_f(:,2), box_size), []);
        %figure;imshow(reshape(average_f_vec, box_size), []);
    end
    out_f = reshape(f_vec, box_size);
end