function [ rec_combine ] = art_ours( f_multi, ang_multi, f_range, iter_l )
%ART_OURS Summary of this function goes here
%   Detailed explanation goes here

w=size(f_multi);

f1 = f_multi(:,:,1);
ang_f1 = ang_multi(1,:);
[W_f1, p_f1, ~, ~] = build_weight_matrix(f1, ang_f1, 1, 'area');
W_combine = W_f1;
p_combine = p_f1;
for i=2:w(3)
    f2 = f_multi(:,:,i);
    ang_f2 = ang_multi(i,:);
    
    [W_f2, p_f2, ~, ~] = build_weight_matrix(f2, ang_f2, 1, 'area');
    W_f2_f_range = W_f2;
    W_f2_f_range(:,find(f_range(:)==0))=0;
    W_f2_f_irange = W_f2;
    W_f2_f_irange(:,find(f_range(:)==1))=0;

    W_combine=[W_combine, zeros(size(W_combine,1),w(1)*w(2)); W_f2_f_range, zeros(size(p_f2,1), w(1)*w(2)*(i-2)), W_f2_f_irange];
    p_combine=[p_combine;p_f2];
end
rec_combine = solver_art(W_combine,p_combine,size(W_combine)*iter_l);
figure;imshow(reshape(rec_combine(1:(w(1)*w(2))),[w(1),w(2)]),[])


end

