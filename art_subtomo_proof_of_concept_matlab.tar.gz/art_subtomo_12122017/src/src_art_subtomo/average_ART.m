function [ average_f, rec_f ] = average_ART( box_size, f_range, W_f, p_f, number_of_particles, iter_l, rec_f)
%AVERAGE_ART Summary of this function goes here
%   Detailed explanation goes here

    %rec_f = zeros(box_size(1), box_size(2), number_of_particles);
    for i=1:number_of_particles
        rec_f_vector = solver_art_ll(full(W_f{i}), p_f{i}, size(full(W_f{i}),1)*iter_l,rec_f(:,:,i));
        rec_f(:,:,i) = reshape(rec_f_vector(:), box_size);
    end
    average_f = f_range.*mean(rec_f, 3);
end