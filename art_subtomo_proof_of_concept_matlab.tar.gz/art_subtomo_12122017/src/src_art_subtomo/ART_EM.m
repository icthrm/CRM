function [ average_f, rec_f] = ART_EM( box_size, f_range, W_f, p_f, number_of_particles, iter_l,rec_f)
%AVERAGE_ART Summary of this function goes here
%   Detailed explanation goes here

    %initial
    %rec_f = zeros(box_size(1)*box_size(2), number_of_particles);
    average_f_vec = zeros(box_size(1)*box_size(2), 1);
    for j = 1:iter_l
        average_f_vec_old = average_f_vec;
        average_f_vec = zeros(box_size(1)*box_size(2), 1);
        for i = 1:number_of_particles
            rec_f(:,i) = solver_art_ll(full(W_f{i}), p_f{i}, size(full(W_f{i}),1),rec_f(:,i));
            average_f_vec = average_f_vec + f_range(:).*rec_f(:,i);
        end
        average_f_vec = average_f_vec / number_of_particles;
        for i = 1:number_of_particles
            rec_f(:,i) = rec_f(:,i).*(1 - f_range(:));
            rec_f(:,i) = rec_f(:,i) + average_f_vec;
        end
        mean((average_f_vec - average_f_vec_old).^2, 1)
        %figure;imshow(reshape(rec_f(:,1), box_size), []);
        %figure;imshow(reshape(rec_f(:,2), box_size), []);
        %figure;imshow(reshape(average_f_vec, box_size), []);
    end
    average_f = reshape(average_f_vec, box_size);
end