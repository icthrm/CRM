function [ rec ] = averaging( f_multi, ang_multi, iter_l )
%AVERAGING Summary of this function goes here
%   Detailed explanation goes here
w=size(f_multi);
rec=zeros(w(1)*w(2),1);
for i=1:w(3)
    f1 = f_multi(:,:,i);
    ang_f1 = ang_multi(i,:);
    
    [W_f1, p_f1, ~, ~] = build_weight_matrix(f1, ang_f1, 1, 'area');
    rec_f1 = solver_art(W_f1,p_f1,size(W_f1)*iter_l);
    rec = rec + rec_f1;
end
rec = rec / w(3);

end

