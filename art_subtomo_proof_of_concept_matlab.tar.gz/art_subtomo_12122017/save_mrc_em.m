number_of_group = 1;
iter_l = 25;
length = 280;
for i=1:number_of_group
    for j=1:iter_l
        load(['rlt/rec_EM/average_EM_f_iter' num2str(j) '_group' num2str(i) '.mat']);
        tom_mrcwrite(average_f((length/4+1):(length/4*3),(length/4+1):(length/4*3)), 'name', ['rlt/rec_EM/average_EM_f_iter' num2str(j) '_group' num2str(i) '.mrc']);
    end
end