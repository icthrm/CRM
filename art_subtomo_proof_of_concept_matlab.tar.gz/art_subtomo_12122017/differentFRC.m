 load('p_noise_f.mat')
load('p_f.mat')
noise_ll = p_noise_f - p_f;
number_of_particles = 90;
for i = 1:number_of_particles
noise_ll{i} = p_noise_f{i} - p_f{i};
end
SNR=50;
for i = 1:number_of_particles
noise_ll{i} = p_noise_f{i}/50^0.5;
end
for i = 1:number_of_particles
p_noise_f_50{i} = p_f{i}+p_noise_f{i};
end
save('p_noise_f_50.mat','p_noise_f_50');