for ((i=1; i<26; ++i))  
do
    for ((j=1; j<2; ++j))
    do
    	echo $i
    	e2proc3d.py rlt/rec_EM/average_EM_f_iter${i}_group${j}.mrc --calcfsc=rlt/mrc/f.mrc rlt/rec_EM/average_EM_f_iter${i}_group${j}.frc
    done
done 
