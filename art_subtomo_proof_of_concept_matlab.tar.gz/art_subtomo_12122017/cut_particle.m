test=tom_mrcreadimod('data/emd_3489_bin180.map');
test1=test.Value;
test1=test1(:,:,90);
test3=test1(25:164,15:154);
test3 = fliplr(test3);
tom_mrcwrite(test3, 'name', 'data/emd_3489_bin180_cut.map');