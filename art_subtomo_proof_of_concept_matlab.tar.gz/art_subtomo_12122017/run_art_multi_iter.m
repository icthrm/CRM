%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%load sample data
load('rlt/simu/f_range.mat');
load('rlt/simu/W_f.mat');
load('rlt/simu/p_f.mat');
%load('rlt/simu/p_noise_f.mat');

%parameters
number_of_particles = 3;
number_of_group = 30;

box_size = size(f_range);
iter_l = 25;
mkdir rlt/rec_art_constraint

%reconstruction
for i=19:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    [ W_combine,p_combine  ] = ART_multi_iter( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), number_of_particles  );
    save(['rlt/rec_art_constraint/art_constraint_W' '_group' num2str(i) '.mat'],'W_combine','-v7.3');
    save(['rlt/rec_art_constraint/art_constraint_p' '_group' num2str(i) '.mat'],'p_combine');
    x = zeros(size(W_combine,2),1);
    for j = 1:iter_l
        tic
        x = solver_art_ll(W_combine,p_combine,size(W_combine,1),x);
        rec = reshape(x(1:(box_size(1)*box_size(2))), box_size);
        save(['rlt/rec_art_constraint/art_constraint_f_iter' num2str(j) '_group' num2str(i) '.mat'],'rec');
        save(['rlt/rec_art_constraint/art_constraint_original_iter' num2str(j) '_group' num2str(i) '.mat'],'x');
        toc
    end
end