function []=run_art_ave(dir, iter_l, number_of_particles, number_of_group, SNR_proj)
%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%load sample data
load([ dir '/simu/f_range.mat']);
load([ dir '/simu/W_f.mat']);
if SNR_proj==0
    load([ dir '/simu/p_f.mat']);
else
	load('rlt/simu/p_noise_f.mat');
    p_f = p_noise_f;
    clear p_noise_f;
end

%parameters
%number_of_particles = 3;
%number_of_group = 30;

%parameters average ART
box_size = size(f_range);
%iter_l = 25;
mkdir([dir '/rec_art_ave']);
%reconstruction
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    rec_f = zeros(box_size(1), box_size(2), number_of_particles);
    for j = 1:iter_l
        tic
        [ average_art_f,rec_f ] = average_ART( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), number_of_particles, 1,rec_f );
        save([dir '/rec_art_ave/average_art_f_iter' num2str(j) '_group' num2str(i) '.mat'],'average_art_f');
        save([dir '/rec_art_ave/average_art_original_iter' num2str(j) '_group' num2str(i) '.mat'],'rec_f');
        toc
    end
end
end