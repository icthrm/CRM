%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%load sample data
load('rlt/simu/f_range.mat');
load('rlt/simu/W_f.mat');
load('rlt/simu/p_f.mat');
%load('rlt/simu/p_noise_f.mat');

%parameters
number_of_particles = 3;
number_of_group = 30;
box_size = size(f_range);
iter_l = 3;
weight_flag = 0;
lambda = 2^(-13);

number_of_particles = 3;
number_of_group = 1;

mkdir rlt/rec_TV_constraint/
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    rec_f = zeros(box_size(1), box_size(2), number_of_particles);
    u = zeros(sum(f_range(:)),number_of_particles - 1);
    for j = 1:iter_l
        [rec_f_out, rec_f, u] = TV_multi_subtomo_iter(box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), 1, weight_flag, number_of_particles, lambda, rec_f, u);
        save(['rlt/rec_TV_constraint/TV_constraint_rec_f_out_iter' num2str(j) '_group' num2str(i) '.mat'],'rec_f_out');
        save(['rlt/rec_TV_constraint/TV_constraint_rec_f_iter' num2str(j) '_group' num2str(i) '.mat'],'rec_f');
        save(['rlt/rec_TV_constraint/TV_constraint_u_iter' num2str(j) '_group' num2str(i) '.mat'],'u');
    end
end