mkdir rlt/frc_art_ave_noise_30
for ((i=1; i<21; ++i))  
do
    for ((j=1; j<4; ++j))
    do
    	echo $i
    	e2proc3d.py rlt/mrc_art_ave_noise_30/CV_iter${i}_group${j}.mrc --calcfsc=rlt/simu/f.mrc rlt/frc_art_ave_noise_30/CV_iter${i}_group${j}.frc
    done
done
