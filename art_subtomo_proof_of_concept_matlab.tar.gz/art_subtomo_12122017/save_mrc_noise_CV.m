number_of_group = 3;
iter_l = 20;
length = 280;
mkdir rlt/mrc_art_CV_noise_30
addpath(genpath(pwd));
for i=1:number_of_group
    for j=1:iter_l
        load(['rlt/rec_art_CV_noise_30/art_CV_f_iter' num2str(j) '_group' num2str(i) '.mat']);
        tom_mrcwrite(average_f((length/4+1):(length/4*3),(length/4+1):(length/4*3)), 'name', ['rlt/mrc_art_CV_noise_30/CV_iter' num2str(j) '_group' num2str(i) '.mrc']);
    end
end