function []=run_simu(save_flag,number_of_particles,delta_angle,number_of_proj, dir,SNR_proj)
% save_flag = 1;
% number_of_particles = 2;
% delta_angle = 3;
% number_of_proj = 2;
% dir='rlt_test';

%SNR_proj = 1;

rng('shuffle'); %rand('state',sum(100*clock)*rand(1));
%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%generate samples
[f_multi, f, f_range] = generate_simu(number_of_particles, 1);
f_multi = single(f_multi);
f = single(f);
f_range = single(f_range);

%generate angles
ang_multi = generate_angles( number_of_particles, delta_angle, number_of_proj);
%angle_all = ang_multi(:)';
ang_multi = single(ang_multi);

%generate projections and coefficient matrix
W_f = cell(1,number_of_particles);
p_f = cell(1, number_of_particles);
%p_f_pure = cell(1, number_of_particles);
p_noise_f = cell(1, number_of_particles);
p_noise = cell(1, number_of_particles);

for i = 1:number_of_particles
    [W_f{i}, p_f{i}, ~, ~] = build_weight_matrix(f_multi(:,:,i), ang_multi(i,:), 1, 'area');
    [~, p_f_pure, ~, ~] = build_weight_matrix(f, ang_multi(i,:), 1, 'area');
    %W_f{i} = single(W_f{i});
    W_f{i} = sparse(W_f{i});
    p_f{i} = single(p_f{i});
    
    p_noise_f{i} = single(randn(size(p_f{i})));
    tmp = p_f_pure;
    p_noise_f{i} = p_noise_f{i} * std(tmp(:)) / SNR_proj;
    p_noise{i} = single(p_noise_f{i} * std(tmp(:)));
    p_noise_f{i} = single(p_f{i} + p_noise_f{i});
    
    i
end
clear p_f_pure;
clear tmp;
%[W_f_all, p_f_all, ~, ~] = build_weight_matrix(f, angle_all, 1, 'area');
clear i;
%save
if save_flag
    mkdir(dir);
    mkdir( [dir,'/simu'] );
    save([dir,'/simu/f_multi.mat'],'f_multi');
    save(   [dir,'/simu/f.mat'],'f'   );
    save([dir,'/simu/f_range.mat'],'f_range');
    save([dir,'/simu/ang_multi.mat'],'ang_multi');
    save([dir,'/simu/W_f.mat'],'W_f', '-v7.3');
    save([dir,'/simu/p_f.mat'],'p_f');
    save([dir,'/simu/p_noise_f.mat'],'p_noise_f');
    save([dir,'/simu/p_noise.mat'],'p_noise');
    %save('rlt/simu/W_f_all.mat','W_f_all','-v7.3');
    %save('rlt/simu/p_f_all.mat','p_f_all');
end
end
