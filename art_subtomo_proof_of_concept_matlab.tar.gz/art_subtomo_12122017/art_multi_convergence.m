%add path
currentFolder = pwd;
addpath(genpath(currentFolder));

%load sample data
load('rlt/simu/f_range.mat');
load('rlt/simu/W_f.mat');
load('rlt/simu/p_f.mat');
%load('rlt/simu/p_noise_f.mat');

%parameters
number_of_particles = 3;
number_of_group = 1;
rec_alg = 'ART_mul';%ART_ave;TV__ave;'TV__mul';ART_mul

if number_of_particles * number_of_group > size(p_f,2)
    break
end

% if number_of_particles * number_of_group > size(p_noise_f,2)
%     break
% end
%%
%ART_average
if rec_alg == 'ART_ave'
%parameters average ART
box_size = size(f_range);
average_art_f = zeros(box_size(1), box_size(2), number_of_group);
iter_l = 10;

%reconstruction
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    [ average_art_f(:,:,i) ] = average_ART( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), number_of_particles, iter_l );
    %[ average_art_f(:,:,i) ] = average_ART( box_size, f_range, W_f(start_num:end_num), p_noise_f(start_num:end_num), number_of_particles, iter_l );
end

%save
mkdir rlt/rec
save('rlt/rec/average_art_f.mat','average_art_f');
end

%%
%TV_average
if rec_alg == 'TV__ave'
%parameters average TV
weight_flag = 1;
box_size = size(f_range);
lambda = 2^(-13);
average_TV_f = zeros(box_size(1), box_size(2), number_of_group);
%rec
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    %[ average_TV_f(:,:,i) ] = average_TV( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), weight_flag, number_of_particles, lambda );
    [ average_TV_f(:,:,i) ] = average_TV( box_size, f_range, W_f(start_num:end_num), p_noise_f(start_num:end_num), weight_flag, number_of_particles, lambda );
end
%save
%mkdir rlt/rec
save('rlt/rec/average_TV_f.mat','average_TV_f');
end

%%
if strcmp(rec_alg,'TV__mul')
%parameters
iteration = 10;
weight_flag = 0;
box_size = size(f_range);
lambda = 2^(-5);
TV_multi_f = zeros(box_size(1), box_size(2), number_of_group);
%rec
for i=1:number_of_group
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    %[TV_multi_f(:,:,i)] = TV_multi_subtomo(box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), iteration, weight_flag, number_of_particles, lambda);
    [TV_multi_f(:,:,i)] = TV_multi_subtomo(box_size, f_range, W_f(start_num:end_num), p_noise_f(start_num:end_num), iteration, weight_flag, number_of_particles, lambda);
end
%save
%save('rlt/rec/TV_multi_f','TV_multi_f');  
%show
figure;imshow(TV_multi_f,[]);
end

%%
if strcmp(rec_alg,'ART_mul')

for iter_l = [15 20 25]
    
    
%iter_l = 1;
box_size = size(f_range);
art_multi_f = zeros(box_size(1), box_size(2), number_of_group);
%rec
for i=1:number_of_group
    tic;
    start_num = (i - 1) * number_of_particles + 1;
    end_num = i * number_of_particles;
    [ art_multi_f(:,:,i) ] = ART_multi( box_size, f_range, W_f(start_num:end_num), p_f(start_num:end_num), number_of_particles ,iter_l );
    %[ art_multi_f(:,:,i) ] = ART_multi( box_size, f_range, W_f(start_num:end_num), p_noise_f(start_num:end_num), number_of_particles ,iter_l );
    art_multi_f(:,:,i) = art_multi_f(:,:,i) .* f_range;
    toc;
    i
end
%save
mkdir rlt/rec
save(['rlt/rec/art_multi_f_iter', num2str(iter_l) '.mat'],'art_multi_f');

end
end

%%
if 0
load('rlt/rec/art_multi_f.mat');
load('rlt/rec/average_art_f.mat');
load('rlt/rec/average_TV_f.mat');
load('rlt/rec/TV_multi_f.mat');
load('rlt/simu/f.mat');

mkdir rlt/mrc
% tom_mrcwrite(art_multi_f, 'name', 'rlt/mrc/art_multi_f.mrc');
% tom_mrcwrite(average_art_f, 'name', 'rlt/mrc/average_art_f.mrc');
% tom_mrcwrite(average_TV_f, 'name', 'rlt/mrc/average_TV_f.mrc');
% tom_mrcwrite(TV_multi_f, 'name', 'rlt/mrc/TV_multi_f.mrc');
% tom_mrcwrite(f, 'name', 'rlt/mrc/f.mrc');

length = 280;
tom_mrcwrite(art_multi_f((length/4+1):(length/4*3),(length/4+1):(length/4*3),:), 'name', 'rlt/mrc/art_multi_f.mrc');
tom_mrcwrite(average_art_f((length/4+1):(length/4*3),(length/4+1):(length/4*3),:), 'name', 'rlt/mrc/average_art_f.mrc');
tom_mrcwrite(average_TV_f((length/4+1):(length/4*3),(length/4+1):(length/4*3),:), 'name', 'rlt/mrc/average_TV_f.mrc');
tom_mrcwrite(TV_multi_f((length/4+1):(length/4*3),(length/4+1):(length/4*3),:), 'name', 'rlt/mrc/TV_multi_f.mrc');
tom_mrcwrite(f((length/4+1):(length/4*3),(length/4+1):(length/4*3),:), 'name', 'rlt/mrc/f.mrc');


end

%%
%{
mkdir rlt/frc
mkdir rlt/mrc_sp
for ((i=0; i<30; ++i))  
do
    echo $i 

    newstack -in rlt/mrc/art_multi_f.mrc -ou rlt/mrc_sp/art_multi_f_${i}.mrc -se ${i}
    newstack -in rlt/mrc/average_art_f.mrc -ou rlt/mrc_sp/average_art_f_${i}.mrc -se ${i}
    newstack -in rlt/mrc/average_TV_f.mrc -ou rlt/mrc_sp/average_TV_f_${i}.mrc -se ${i}
    newstack -in rlt/mrc/TV_multi_f.mrc -ou rlt/mrc_sp/TV_multi_f_${i}.mrc -se ${i}

    e2proc3d.py rlt/mrc_sp/art_multi_f_${i}.mrc --calcfsc=rlt/mrc/f.mrc rlt/frc/art_multi_f_${i}.frc
    e2proc3d.py rlt/mrc_sp/average_art_f_${i}.mrc --calcfsc=rlt/mrc/f.mrc rlt/frc/average_art_f_${i}.frc
    e2proc3d.py rlt/mrc_sp/average_TV_f_${i}.mrc --calcfsc=rlt/mrc/f.mrc rlt/frc/average_TV_f_${i}.frc
    e2proc3d.py rlt/mrc_sp/TV_multi_f_${i}.mrc --calcfsc=rlt/mrc/f.mrc rlt/frc/TV_multi_f_${i}.frc
done 
%}

%%
if 0

TV_multi_list = dir('rlt/frc/TV_multi_f_*.frc');
%TV_multi_list = dir('rlt/frc/average_art_f_*.frc');
%TV_multi_list = dir('rlt/frc/average_TV_f_*.frc');
%TV_multi_list = dir('rlt/frc/art_multi_f_*.frc');

l = length(TV_multi_list);
tmp = load(['rlt/frc/', TV_multi_list(1).name]);
frc_all = zeros(size(tmp,1), l*2);
for i=1:l
	frc_all(:,(2*i-1):(2*i)) = load(['rlt/frc/', TV_multi_list(i).name]);
end
ave_TV_multi = mean(frc_all(:,2:2:end),2);
std_TV_multi = std(frc_all(:,2:2:end),0,2);
x= frc_all(:,1)*2;
figure;errorbar(x,ave_TV_multi,std_TV_multi);


mkdir rlt/final
save('rlt/final/frc_ave_TV_multi.mat', 'ave_TV_multi');
save('rlt/final/frc_std_TV_multi.mat', 'std_TV_multi');
save('rlt/final/x.mat', 'x');
%{
save('rlt/final/frc_ave_average_art.mat', 'ave_TV_multi');
save('rlt/final/frc_std_average_art.mat', 'std_TV_multi');

save('rlt/final/frc_ave_average_TV.mat', 'ave_TV_multi');
save('rlt/final/frc_std_average_TV.mat', 'std_TV_multi');

save('rlt/final/frc_ave_art_multi.mat', 'ave_TV_multi');
save('rlt/final/frc_std_art_multi.mat', 'std_TV_multi');
%}

%{
x = load('rlt/final/x.mat');

ave1 = load('rlt/final/frc_ave_TV_multi.mat');
std1 = load('rlt/final/frc_std_TV_multi.mat');

ave2 = load('rlt/final/frc_ave_average_art.mat');
std2 = load('rlt/final/frc_std_average_art.mat');

ave3 = load('rlt/final/frc_ave_average_TV.mat');
std3 = load('rlt/final/frc_std_average_TV.mat');

ave4 = load('rlt/final/frc_ave_art_multi.mat');
std4 = load('rlt/final/frc_std_art_multi.mat');


figure;hold on;
errorbar(x.x,ave1.ave_TV_multi,std1.std_TV_multi,'r');
errorbar(x.x,ave2.ave_TV_multi,std2.std_TV_multi,'b');
errorbar(x.x,ave3.ave_TV_multi,std3.std_TV_multi,'k');
errorbar(x.x,ave4.ave_TV_multi,std4.std_TV_multi,'g');

figure;hold on;
errorbar(x.x,ave1.ave_TV_multi,(std1.std_TV_multi).^2,'r', 'LineWidth', 2, 'markersize',18);
errorbar(x.x,ave2.ave_TV_multi,(std2.std_TV_multi).^2,'b', 'LineWidth', 2, 'markersize',18);
errorbar(x.x,ave3.ave_TV_multi,(std3.std_TV_multi).^2,'k', 'LineWidth', 2, 'markersize',18);
errorbar(x.x,ave4.ave_TV_multi,(std4.std_TV_multi).^2,'g', 'LineWidth', 2, 'markersize',18);

xlabel({'Fraction of Nyquist'}, 'FontSize', 14);
ylabel({'Fourier Ring Correlation'}, 'FontSize', 14);
legend({'TV constrainted','average art','average TV','art constrainted'}, 'FontSize', 16, 'Location', 'SouthWest');
%}

end