iter_l=25;
number_of_particles_pergroup=3;
number_of_group=30;
save_flag = 1;
SNR_proj = 0;
number_of_particles_all=number_of_particles_pergroup*number_of_group;

for delta_angle = [2 3]
    for angle = [50 60]
        number_of_proj = floor(angle*2/delta_angle)+1;
        dir=['rlt_', num2str(delta_angle),'_',num2str(angle),'_', num2str(SNR_proj)];
        if SNR_proj == 0
            run_simu(save_flag,number_of_particles_all,delta_angle,number_of_proj, dir,1);
            run_art_CV(dir, iter_l, number_of_particles_pergroup, number_of_group,SNR_proj);
            run_art_ave(dir, iter_l, number_of_particles_pergroup, number_of_group,SNR_proj);
        else
            run_simu(save_flag,number_of_particles_all,delta_angle,number_of_proj, dir,SNR_proj);
            run_art_CV(dir, iter_l, number_of_particles_pergroup, number_of_group,SNR_proj);
            run_art_ave(dir, iter_l, number_of_particles_pergroup, number_of_group,SNR_proj);
        end
    end
end